import streamlit as st
from streamlit_authenticator import Authenticate
from agents.router import route_user_query
from utils.logger import setup_logger

logger = setup_logger()

# Simple user config
users = {
    "usernames": {
        "admin": {
            "name": "Admin User",
            "password": "admin123"
        }
    }
}

authenticator = Authenticate(users, "auth", "abcdef", cookie_expiry_days=1)

name, authentication_status, username = authenticator.login("Login", "main")

if authentication_status:
    st.title("Command-R CrewAI Chat with Auth")
    prompt = st.text_input("Ask me something:")
    if prompt:
        logger.info(f"[{username}] User input: {prompt}")
        result = route_user_query(prompt)
        logger.info(f"[{username}] Response: {result}")
        st.markdown(f"**Response:**\n{result}")
elif authentication_status is False:
    st.error("Username or password is incorrect")
elif authentication_status is None:
    st.warning("Please enter your username and password")