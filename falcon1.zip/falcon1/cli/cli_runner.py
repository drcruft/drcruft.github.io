import argparse
from router import route_query
from tools.rag_tool import RAGTool
from tools.splunk_tool import SplunkTool
from logger import log_interaction

import requests

COMMANDR_API_URL = "http://localhost:11434/api/generate"

def call_commandr_llm(prompt: str) -> str:
    response = requests.post(
        COMMANDR_API_URL,
        json={"prompt": prompt, "model": "commandr"}
    )
    return response.json().get("response", "No response from LLM.")

def handle_query(query: str) -> str:
    route = route_query(query)

    if route == "llm":
        response = call_commandr_llm(query)
    elif route == "rag":
        rag_tool = RAGTool()
        response = rag_tool.run(query)
    elif route == "splunk":
        splunk_tool = SplunkTool()
        response = splunk_tool.run(query)
    else:
        response = "Could not classify query."

    log_interaction(query, route, response)
    return response

def interactive_mode():
    print("Interactive LLM CLI (type 'exit' to quit)")
    while True:
        query = input("You > ")
        if query.strip().lower() == "exit":
            break
        print("\n[Routing & Response]")
        response = handle_query(query)
        print(f"{response}\n")

def file_mode(file_path: str):
    with open(file_path, 'r') as f:
        queries = [line.strip() for line in f if line.strip()]
    
    for q in queries:
        print(f"\n> {q}")
        response = handle_query(q)
        print(response)

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="LLM CLI with routing and logging")
    parser.add_argument("-f", "--file", help="File containing queries (one per line)")
    args = parser.parse_args()

    if args.file:
        file_mode(args.file)
    else:
        interactive_mode()
