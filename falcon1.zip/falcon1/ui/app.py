import os
import json
import streamlit as st
from pathlib import Path
from router import route_query
from tools.rag_tool import RAGTool
from tools.splunk_tool import SplunkTool
from logger import log_interaction, log_audit_event
from auth.auth import check_login
import requests

COMMANDR_API_URL = "http://localhost:11434/api/generate"

def call_commandr_llm(prompt: str) -> str:
    response = requests.post(
        COMMANDR_API_URL,
        json={"prompt": prompt, "model": "commandr"}
    )
    return response.json().get("response", "No response from LLM.")

def handle_query(query: str):
    route = route_query(query)
    if route == "llm":
        response = call_commandr_llm(query)
    elif route == "rag":
        rag_tool = RAGTool()
        response = rag_tool.run(query)
    elif route == "splunk":
        splunk_tool = SplunkTool()
        response = splunk_tool.run(query)
    else:
        response = "Could not classify query."
    log_interaction(query, route, response)
    return route, response

# -------------------- STREAMLIT UI --------------------

st.set_page_config(page_title="CrewAI + Command-R", layout="wide")

# Simple login mechanism
if "logged_in" not in st.session_state:
    st.session_state.logged_in = False

if not st.session_state.logged_in:
    st.title("🔐 Login to CrewAI Assistant")
    username = st.text_input("Username")
    password = st.text_input("Password", type="password")
    if st.button("Login"):
        if check_login(username, password):
            st.session_state.logged_in = True
            st.session_state.username = username
            st.success(f"Welcome, {username}!")
        else:
            st.error("Invalid username or password")
    st.stop()

# Session tracking
st.title("🤖 CrewAI Assistant")
st.markdown("Ask any question. The AI routes to LLM, RAG, or Splunk automatically.")

if "history" not in st.session_state:
    st.session_state["history"] = []

query = st.text_input("💬 Ask your question here:")

if query:
    route, response = handle_query(query)
    st.session_state["history"].insert(0, {
        "query": query,
        "route": route,
        "response": response
    })

    # Save session to file
    user_file = Path(f"user_sessions/session_log_{st.session_state.username}.json")
    user_file.parent.mkdir(exist_ok=True)
    with open(user_file, "w") as f:
        json.dump(st.session_state["history"], f, indent=2)

# Show history
st.markdown("### 🔁 Conversation History")
for entry in st.session_state["history"]:
    with st.expander(f"{entry['query']}"):
        st.write(f"**Route:** `{entry['route']}`")
        st.markdown(entry['response'])

# ---------------- Sidebar: File Upload + RAG ----------------

st.sidebar.title("📁 Document RAG Settings")
rag_tool = RAGTool()

uploaded_files = st.sidebar.file_uploader(
    "Upload new documents (PDF, DOCX, TXT):",
    type=["pdf", "docx", "txt"],
    accept_multiple_files=True
)

new_files_uploaded = False
if uploaded_files:
    for file in uploaded_files:
        path = os.path.join("rag_data", file.name)
        with open(path, "wb") as f:
            f.write(file.read())
        log_audit_event(f"[{st.session_state.username}] Uploaded file: {file.name}")
    new_files_uploaded = True
    st.sidebar.success(f"Uploaded {len(uploaded_files)} files.")

if new_files_uploaded:
    chunks = rag_tool.index_documents()
    log_audit_event(f"[{st.session_state.username}] Reindexed RAG with {chunks} chunks.")
    st.sidebar.success(f"RAG index updated with {chunks} chunks.")

# Display uploaded files
st.sidebar.markdown("### 📄 Indexed Files:")
for fname in rag_tool.list_uploaded_files():
    st.sidebar.markdown(f"- {fname}")

# Display last index time
st.sidebar.markdown("### ⏱ Last Indexed:")
st.sidebar.info(rag_tool.get_last_indexed_time())
