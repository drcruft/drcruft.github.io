from crewai import Agent
from tools.rag_tool import RAGTool
from tools.splunk_tool import SplunkTool

prompt_agent = Agent(
    role="LLM Prompt Handler",
    goal="Interpret user queries and dispatch tasks to the right agent",
    backstory="An intelligent assistant that knows when to call RAG or Splunk tools",
    tools=[],
    verbose=True
)
