from crewai import Agent
from tools.splunk_tool import SplunkTool

splunk_agent = Agent(
    role="Splunk Agent",
    goal="Query Splunk and return accurate results",
    backstory="Expert in interacting with Splunk's REST API and querying logs",
    tools=[SplunkTool()],
    verbose=True
)
