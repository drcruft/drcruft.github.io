from crewai import Agent
from tools.rag_tool import RAGTool

rag_agent = Agent(
    role="RAG Agent",
    goal="Answer queries based on documents using vector search",
    backstory="Reads and indexes knowledge from PDFs, DOCX, and text files",
    tools=[RAGTool()],
    verbose=True
)
