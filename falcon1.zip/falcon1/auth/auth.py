import hashlib

# Dummy user store (replace with DB or config later)
USERS = {
    "admin": "admin123",
    "analyst": "qwerty99!@#$"
}

def hash_password(password):
    return hashlib.sha256(password.encode()).hexdigest()

def check_login(username, password):
    if username in USERS and USERS[username] == password:
        return True
    return False
