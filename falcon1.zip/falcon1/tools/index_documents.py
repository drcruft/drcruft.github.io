# tools/index_documents.py
# Run this once to index files
loaders = [
    PyMuPDFLoader("documents/file.pdf"),
    TextLoader("documents/file.txt"),
    Docx2txtLoader("documents/file.docx")
]
docs = []
for loader in loaders:
    docs.extend(loader.load())
splitter = RecursiveCharacterTextSplitter(chunk_size=500, chunk_overlap=100)
docs_split = splitter.split_documents(docs)

embeddings = HuggingFaceEmbeddings()
db = FAISS.from_documents(docs_split, embeddings)
db.save_local("vectorstore/faiss_index")
