import os
import time
from langchain.vectorstores import FAISS
from langchain.embeddings import HuggingFaceEmbeddings
from langchain.document_loaders import PyPDFLoader, TextLoader, Docx2txtLoader
from langchain.text_splitter import RecursiveCharacterTextSplitter

UPLOAD_DIR = "rag_data"
VECTOR_DIR = "vectorstore"
TIMESTAMP_FILE = os.path.join(VECTOR_DIR, "last_indexed.txt")

os.makedirs(UPLOAD_DIR, exist_ok=True)
os.makedirs(VECTOR_DIR, exist_ok=True)

class RAGTool:
    def __init__(self):
        self.embedding_model = HuggingFaceEmbeddings(model_name="sentence-transformers/all-MiniLM-L6-v2")

    def load_all_documents(self):
        docs = []
        for filename in os.listdir(UPLOAD_DIR):
            path = os.path.join(UPLOAD_DIR, filename)
            if filename.endswith(".pdf"):
                loader = PyPDFLoader(path)
            elif filename.endswith(".docx"):
                loader = Docx2txtLoader(path)
            elif filename.endswith(".txt"):
                loader = TextLoader(path)
            else:
                continue
            docs.extend(loader.load())
        return docs

    def index_documents(self):
        documents = self.load_all_documents()
        splitter = RecursiveCharacterTextSplitter(chunk_size=500, chunk_overlap=50)
        split_docs = splitter.split_documents(documents)
        vectorstore = FAISS.from_documents(split_docs, self.embedding_model)
        vectorstore.save_local(VECTOR_DIR)
        with open(TIMESTAMP_FILE, "w") as f:
            f.write(str(time.time()))
        return len(split_docs)

    def get_last_indexed_time(self):
        if os.path.exists(TIMESTAMP_FILE):
            ts = float(open(TIMESTAMP_FILE).read())
            return time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(ts))
        return "Never"

    def list_uploaded_files(self):
        return [f for f in os.listdir(UPLOAD_DIR) if f.endswith((".pdf", ".docx", ".txt"))]

    def run(self, query: str) -> str:
        vectorstore = FAISS.load_local(VECTOR_DIR, self.embedding_model, allow_dangerous_deserialization=True)
        retriever = vectorstore.as_retriever()
        docs = retriever.get_relevant_documents(query)
        if not docs:
            return "No relevant documents found."
        return "\n\n".join(doc.page_content[:1000] for doc in docs[:3])
