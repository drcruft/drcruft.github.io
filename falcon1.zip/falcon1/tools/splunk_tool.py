import requests
import os
from crewai import Tool

class SplunkTool(Tool):
    name = "Splunk Query Tool"
    description = "Tool to query Splunk logs"

    def run(self, query: str) -> str:
        splunk_url = os.getenv("SPLUNK_URL")
        token = os.getenv("SPLUNK_TOKEN")
        headers = {
            "Authorization": f"Bearer {token}",
            "Content-Type": "application/json"
        }
        payload = {
            "search": f"search {query}",
            "exec_mode": "blocking"
        }
        response = requests.post(f"{splunk_url}/services/search/jobs/export",
                                 headers=headers, json=payload, verify=False)
        return response.text
