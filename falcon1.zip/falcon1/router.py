import requests

COMMANDR_API_URL = "http://localhost:11434/api/generate"

def route_query(user_input: str) -> str:
    """Route query to one of: 'llm', 'rag', or 'splunk'"""
    routing_prompt = f"""
You are a routing agent. Classify the following user query into one of the following categories:
- 'llm' for general prompts or chit-chat
- 'rag' for knowledge-based lookups in uploaded documents (PDFs, DOCX, TXT)
- 'splunk' for anything related to system logs, metrics, events, or monitoring

Only respond with one word: llm, rag, or splunk.

Query: "{user_input}"
Answer:"""

    response = requests.post(
        COMMANDR_API_URL,
        json={
            "prompt": routing_prompt,
            "model": "commandr",
            "temperature": 0.0,
            "max_tokens": 5
        }
    )

    if response.ok:
        result = response.json().get("response", "").strip().lower()
        if result in {"llm", "rag", "splunk"}:
            return result
    return "llm"  # fallback default
