from router import route_query
from tools.rag_tool import RAGTool
from tools.splunk_tool import SplunkTool
from logger import log_interaction

import requests

COMMANDR_API_URL = "http://localhost:11434/api/generate"

def call_commandr_llm(prompt: str) -> str:
    response = requests.post(
        COMMANDR_API_URL,
        json={"prompt": prompt, "model": "commandr"}
    )
    return response.json().get("response", "Sorry, no response from LLM.")

def main():
    while True:
        user_input = input("\nAsk something (or type 'exit'): ")
        if user_input.lower() == "exit":
            break

        route = route_query(user_input)
        print(f"[Routing Decision] → {route}")

        if route == "llm":
            response = call_commandr_llm(user_input)
        elif route == "rag":
            rag_tool = RAGTool()
            response = rag_tool.run(user_input)
        elif route == "splunk":
            splunk_tool = SplunkTool()
            response = splunk_tool.run(user_input)
        else:
            response = "Could not classify the input."

        print(f"\n[Response]:\n{response}")
        log_interaction(user_input, route, response)

if __name__ == "__main__":
    main()
