import logging
import os
import re
from datetime import datetime

# Directories
LOG_DIR = "logs"
REDACTED_LOG = os.path.join(LOG_DIR, "interactions_redacted.log")
RAW_LOG = os.path.join(LOG_DIR, "interactions_raw.log")
AUDIT_LOG = os.path.join(LOG_DIR, "audit.log")

os.makedirs(LOG_DIR, exist_ok=True)

# Setup redacted log
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
    handlers=[
        logging.FileHandler(REDACTED_LOG),
        logging.StreamHandler()
    ]
)

# Raw log logger (no redaction)
raw_logger = logging.getLogger("raw_logger")
raw_handler = logging.FileHandler(RAW_LOG)
raw_handler.setFormatter(logging.Formatter("%(asctime)s [%(levelname)s] %(message)s"))
raw_logger.setLevel(logging.INFO)
raw_logger.addHandler(raw_handler)

# Audit logger
audit_logger = logging.getLogger("audit_logger")
audit_handler = logging.FileHandler(AUDIT_LOG)
audit_handler.setFormatter(logging.Formatter("%(asctime)s [%(levelname)s] %(message)s"))
audit_logger.setLevel(logging.INFO)
audit_logger.addHandler(audit_handler)

# Patterns for redaction
REDACTION_PATTERNS = {
    "email": r"\b[\w\.-]+@[\w\.-]+\.\w{2,4}\b",
    "ip": r"\b(?:\d{1,3}\.){3}\d{1,3}\b",
    "token": r"(?i)\b(?:token|apikey|secret)[=:]?\s*[\w-]{10,}\b",
    "credit_card": r"\b(?:\d[ -]*?){13,16}\b",
    "phone": r"\b(?:\+?\d{1,3})?[ -.]?\(?\d{2,4}\)?[ -.]?\d{3,4}[ -.]?\d{3,4}\b"
}

def redact_sensitive_content(text: str) -> str:
    redacted = text
    for label, pattern in REDACTION_PATTERNS.items():
        redacted = re.sub(pattern, f"[REDACTED:{label}]", redacted, flags=re.IGNORECASE)
    return redacted

def log_interaction(query: str, route: str, response: str):
    redacted_query = redact_sensitive_content(query)
    redacted_response = redact_sensitive_content(response)

    # Redacted log
    logging.info(f"[ROUTE] {route}")
    logging.info(f"[QUERY] {redacted_query}")
    logging.info(f"[RESPONSE] {redacted_response}")

    # Raw log
    raw_logger.info(f"[ROUTE] {route}")
    raw_logger.info(f"[QUERY] {query}")
    raw_logger.info(f"[RESPONSE] {response}")

def log_audit_event(event: str):
    audit_logger.info(f"[AUDIT] {event}")
