# Command-R CrewAI Chat App with Auth

This app includes:
- Local Command-R LLM via API
- CrewAI-based prompt routing
- Streamlit UI with basic authentication
- Full logging/auditing to logs/chat_app.log

## Setup

1. Create a virtual environment and activate it
2. Install dependencies:
   ```
   pip install -r requirements.txt
   ```
3. Set `.env` values:
   ```
   COMMANDR_API_BASE=http://localhost:11434/v1
   COMMANDR_API_KEY=dummy-key
   ```
4. Run the app:
   ```
   streamlit run main.py
   ```