from langchain.chat_models import ChatOpenAI
from crewai import Agent, Task, Crew
import os
from utils.logger import setup_logger

logger = setup_logger()

llm = ChatOpenAI(
    model="command-r",
    openai_api_base=os.environ.get("COMMANDR_API_BASE"),
    openai_api_key=os.environ.get("COMMANDR_API_KEY"),
    temperature=0.7
)

def route_user_query(prompt):
    router_agent = Agent(
        role="Router",
        goal="Decide whether to handle the query or route it to a tool",
        backstory="You analyze user queries and decide the best handling approach",
        verbose=True,
        llm=llm
    )

    commandr_agent = Agent(
        role="Command-R",
        goal="Answer questions directly using the Command-R model",
        backstory="A general-purpose local LLM for handling user queries",
        verbose=True,
        llm=llm
    )

    routing_task = Task(
        description=f"Decide how to handle: '{prompt}'",
        expected_output="Respond directly or decide to call a tool agent later.",
        agent=router_agent
    )

    crew = Crew(
        agents=[router_agent, commandr_agent],
        tasks=[routing_task],
        verbose=True
    )

    result = crew.kickoff()
    logger.info(f"Routing decision and response: {result}")
    return result